﻿using FinaLabOne;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalLabOne
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book("book", "book author", "a13", "oop2");
            string book = b1.GetBook();
            Console.WriteLine(book);
            b1.ShowBookInfo();
            Console.WriteLine();

            Library l1 = new Library("Library", "address", 12); //, new Book("Book1", "Book Author", "Book Id", "Book Type")
            //l1.AddNewBook(12);
            l1.ShowLibInfo();

            Contact c1 = new Contact("Person", 20, "01555555555", 'M');
            c1.ShowContactInfo();
            Console.WriteLine();

            ContactBook cb1 = new ContactBook("Contact", "Address", 12);
            cb1.ShowInfo();
            Console.WriteLine();

            Console.ReadLine();
        }
    }
}