﻿using FinalLabOne;
using System;
namespace FinaLabOne
{
    class ContactBook
    {
        private string ownerName;
        private string ownerAddress;
        private Contact[] listOfContact;

        public ContactBook(string OwnerName, string OwnerAddress, int list)
        {
            this.ownerName = OwnerName;
            this.ownerAddress = OwnerAddress;
            listOfContact = new Contact[list];

        }
        public string OwnerName
        {
            get { return ownerName; }
            set { ownerName = value; }
        }
        public string OwnerAddress
        {
            get { return ownerAddress; }
            set { ownerAddress = value; }
        }
        void AddContact(Contact con)
        {
            for (int i = 0; i < listOfContact.Length; i++)
            {
                if (listOfContact[i] == con)
                {
                    listOfContact[i] = con;
                    Console.WriteLine("Contact Added");
                    break;
                }
            }
        }
        public void ShowInfo() //show all info of contactBook and contact
        {
            Console.WriteLine("");
        }
    }
}
